<?php
class UserTeam extends DbModel
{
    protected static $table = 'user_teams';

}