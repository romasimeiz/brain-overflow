<?php
class Comment extends DbModel
{
    protected static $table = 'comments';

}