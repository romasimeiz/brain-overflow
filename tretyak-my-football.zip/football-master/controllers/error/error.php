<?php 

$data = null;

view('error' , $data);
