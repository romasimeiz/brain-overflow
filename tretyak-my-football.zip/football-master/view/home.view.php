<h1>Матчи</h1>

<?php require BASE_DIR.'/view/common/games_list.view.php';?>
